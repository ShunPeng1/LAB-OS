#!/bin/sh

echo $(date) >> "$(dirname "$0")/date-out.txt"
