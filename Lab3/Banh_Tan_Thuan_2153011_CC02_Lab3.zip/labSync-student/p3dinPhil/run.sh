clear
make clean
make dinPhil
./dinPhil