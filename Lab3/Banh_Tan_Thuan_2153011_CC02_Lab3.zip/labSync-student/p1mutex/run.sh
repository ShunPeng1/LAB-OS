clear
make clean
make shrdmem
./shrdmem