clear
make clear
make pc
./pc