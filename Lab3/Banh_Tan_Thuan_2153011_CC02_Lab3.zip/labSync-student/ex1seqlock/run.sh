clear
make clear
make seqlock
./seqlock