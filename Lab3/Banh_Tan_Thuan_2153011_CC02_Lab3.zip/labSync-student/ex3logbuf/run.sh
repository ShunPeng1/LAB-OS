clear
make clear
make logbuf
./logbuf 