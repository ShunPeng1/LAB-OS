clear
make clear
make all
./main "$@"