make clean
make all
./sum_multi-thread 10 1000000
./sum_serial 1000000