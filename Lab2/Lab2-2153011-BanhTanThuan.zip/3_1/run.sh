clear
make clean
make shareMem
./shareMem