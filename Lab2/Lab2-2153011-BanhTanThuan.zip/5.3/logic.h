#ifndef LOGIC_H
#define LOGIC_H

void calculate(float first, char operator, float second, float *ans);
void history(char hist[100][100], int len);

#endif
