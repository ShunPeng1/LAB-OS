make clean
make all
./all