clear
make clean
make pipe
./pipe